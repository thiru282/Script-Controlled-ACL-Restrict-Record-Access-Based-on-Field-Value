# 5. Project Development Phase

## ACL Setup Example

Create a **Record ACL** for the required table.

- Type: `record`
- Operation: `read`
- Name: your table name
- Advanced: enabled
- Script: use `Scripted_ACL.js`

## Important
Replace sample names such as:
- `u_access_level`
- `requested_for`
- `x_app.secure_reader`

with the actual fields and roles from your ServiceNow project.

## Suggested Field Values
- public
- private
- restricted
