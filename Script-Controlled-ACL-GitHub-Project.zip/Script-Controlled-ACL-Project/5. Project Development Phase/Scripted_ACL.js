/*
Project: Script-Controlled ACL – Restrict Record Access Based on Field Value

Example assumptions:
- Field: u_access_level
- Possible values: public, private, restricted
- Owner field: requested_for
- Restricted role: x_app.secure_reader

Use the field/table names that exist in your own ServiceNow instance.
*/

answer = false;

var accessLevel = current.getValue('u_access_level');

// Public records
if (accessLevel == 'public') {
    answer = true;
}

// Record owner
else if (
    current.getValue('requested_for') &&
    current.getValue('requested_for') == gs.getUserID()
) {
    answer = true;
}

// Admin override
else if (gs.hasRole('admin')) {
    answer = true;
}

// Restricted-reader role
else if (
    accessLevel == 'restricted' &&
    gs.hasRole('x_app.secure_reader')
) {
    answer = true;
}

// All other cases remain denied.
