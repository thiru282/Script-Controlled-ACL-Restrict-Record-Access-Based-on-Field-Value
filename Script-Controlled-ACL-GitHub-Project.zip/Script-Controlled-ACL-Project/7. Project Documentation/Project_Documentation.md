# 7. Project Documentation

## Title
Script-Controlled ACL – Restrict Record Access Based on Field Value

## Abstract
This project implements a scripted Access Control List in ServiceNow to control record visibility dynamically. The ACL checks a record field value and grants access only when defined security conditions are satisfied.

## Benefits
- Better data protection
- Dynamic access decisions
- Role-aware security
- Easy customization
- Centralized access logic

## Future Enhancements
- Group-based access
- Department-based access
- Location-based access
- Approval-based access
- Audit logging
