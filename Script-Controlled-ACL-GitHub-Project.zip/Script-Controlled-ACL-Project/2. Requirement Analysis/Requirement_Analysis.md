# 2. Requirement Analysis

## Functional Requirements
- Check the value of a selected field.
- Identify the logged-in user.
- Verify user roles when needed.
- Allow or deny access dynamically.
- Prevent unauthorized record reading.

## Non-Functional Requirements
- Security
- Fast execution
- Maintainable script
- Easy testing

## Platform Requirements
- ServiceNow instance
- A table with a field such as `u_access_level`
- Appropriate user accounts and roles
