# 6. Project Testing

| Test Case | Field Value | User Condition | Expected Result |
|---|---|---|---|
| TC01 | public | Normal user | Allow |
| TC02 | private | Record owner | Allow |
| TC03 | private | Other normal user | Deny |
| TC04 | restricted | User has secure_reader role | Allow |
| TC05 | restricted | User has no required role | Deny |
| TC06 | any | Admin | Allow |

## Testing Method
Use **Impersonate User** or dedicated test accounts and confirm whether the record is visible.

## Success Criteria
Every test case should match the expected access result.
