# 3. Project Design Phase

## Logic Flow

1. User requests a record.
2. ServiceNow evaluates the ACL.
3. Script reads the record's access field.
4. Script checks the current user and role.
5. Access is allowed or denied.

## Sample Decision Logic

```text
IF access_level == "public"
    ALLOW
ELSE IF current user is record owner
    ALLOW
ELSE IF user has admin role
    ALLOW
ELSE
    DENY
```

## Security Principle
Use least privilege: users should receive only the access they actually need.
