# Script-Controlled ACL – Restrict Record Access Based on Field Value

## Project Overview
This project demonstrates how a **Script-Controlled Access Control List (ACL)** can restrict record access based on the value of a field.

### Example Use Case
A user can read a record only when:
- the record is marked as **Public**, or
- the logged-in user is the **Requested For** user, or
- the user has an authorized role such as `admin`.

## Repository Structure
1. Brainstorming & Ideation  
2. Requirement Analysis  
3. Project Design Phase  
4. Project Planning Phase  
5. Project Development Phase  
6. Project Testing  
7. Project Documentation  
8. Project Demonstration  

## Technology
- ServiceNow
- JavaScript
- ACL / Security Rules

## Objective
To implement secure, field-value-based record access using a scripted ACL.
