# 8. Project Demonstration

## Demo Steps
1. Open the target ServiceNow table.
2. Show the field used for access control.
3. Open the scripted ACL.
4. Explain the ACL script.
5. Test a `public` record.
6. Test a `private` record as its owner.
7. Test the same record as another user.
8. Test a `restricted` record with and without the required role.
9. Show that unauthorized access is denied.

## Demo Conclusion
The scripted ACL successfully restricts record access according to the selected field value and user permissions.
