# 1. Brainstorming & Ideation

## Problem Statement
Organizations often need to protect records depending on the value stored in a field.

## Proposed Idea
Create a scripted ACL that checks a field value before allowing record access.

## Example
If `u_access_level` is:
- `public` → allow access
- `private` → allow only the record owner or admin
- `restricted` → allow only users with a specific role

## Expected Outcome
Unauthorized users cannot read protected records.
