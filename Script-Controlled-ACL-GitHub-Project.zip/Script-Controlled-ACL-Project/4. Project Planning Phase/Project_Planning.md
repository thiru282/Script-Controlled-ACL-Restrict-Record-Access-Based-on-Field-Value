# 4. Project Planning Phase

## Tasks
- Create or choose the target table.
- Create an access-control field.
- Prepare test users and roles.
- Create the ACL rule.
- Add the ACL script.
- Test with multiple field values.
- Record results.
- Prepare project documentation.

## Deliverables
- ACL configuration
- ACL script
- Test cases
- Documentation
- Demo steps
